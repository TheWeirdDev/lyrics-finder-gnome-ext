
// Prefrence keys

var   PANEL_POS      =    'panel-pos';
var   TEXT_SIZE      =    'text-size';
var   TEXT_ALIGN     =    'text-align';
var   COVER_SIZE     =    'image-size';
var   SEARCH_LIMIT   =    'search-limit';
var   REMOVE_EXTRAS  =    'remove-extras';
var   FONT_NAME      =    'font-name';
var   ENABLE_COVER   =    'enable-album-cover';
var   SAVE_LYRICS    =    'save-lyrics';
var   AUTO_SEARCH    =    'auto-search';
var   PANEL_WIDTH    =    'panel-width';
var   USE_COLOR      =    'use-color';
var   COLOR          =    'color';